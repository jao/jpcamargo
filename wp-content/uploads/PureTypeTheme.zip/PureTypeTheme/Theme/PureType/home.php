<?php get_header(); ?>

<div id="container">
<?php include(TEMPLATEPATH . '/includes/post_format.php'); ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
</body>
</html>
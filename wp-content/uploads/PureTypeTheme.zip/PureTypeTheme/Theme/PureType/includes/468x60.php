 <a href="<?php echo $puretype_banner_468_url; ?>"><img src="<?php echo $puretype_banner_468; ?>" alt="banner ad" style="float: left; margin-left: 80px; border: none;" /></a>
<div style="clear: both;"></div>

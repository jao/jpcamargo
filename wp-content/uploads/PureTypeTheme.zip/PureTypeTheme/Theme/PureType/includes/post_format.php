<div id="left-div">
   <?php if (get_option('puretype_format') == 'on') { ?>
		<?php include(TEMPLATEPATH . '/includes/blogstyle.php'); ?>
    <?php } else { include(TEMPLATEPATH . '/includes/default.php'); } ?>
</div>
<div class="sidebar-box"> <span class="sidebar-box-title">about me</span>
    <div style="clear: both;"></div>
    <img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $artsee_about_image; ?>&amp;h=68&amp;w=68&amp;zc=1" alt="about me" id="about-image" /> <?php echo $artsee_about_text; ?> </div>

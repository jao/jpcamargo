<span class="current-category">
<?php single_cat_title('Currently Browsing: ', 'display'); ?>
</span>
<?php include(TEMPLATEPATH . '/includes/defaultindex.php'); ?>